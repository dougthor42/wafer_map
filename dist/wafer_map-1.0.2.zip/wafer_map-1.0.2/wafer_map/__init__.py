# -*- coding: utf-8 -*-
"""
wafer_map

This is the wafer_map package. It's designed to be a fast, easy-to-use
plotting package for semiconductor wafer probe data.
"""

__version__ = "1.0.2"
